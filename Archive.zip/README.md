# EPACRIS-1
ExoPlanet Atmospheric Chemistry and Radiative Interaction Simulator

To compile
gcc main_temp.c (gray-atmosphere radiation and convective adjustment)
and run ./a.out

or gcc main_temp_rc.c (line-by-line radiation and convective adjustment)

Parameter files are typically planet_*.h. Each main_*.c will include one planet_*.h file.
